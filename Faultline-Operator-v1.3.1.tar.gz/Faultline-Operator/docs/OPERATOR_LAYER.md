# Operator Layer — Faultline Observatory Platform

## What this is

This is Layer 1 (Operator Console) of the Operator Layer for the Faultline
Observatory Platform. It turns the Synology from a passive Docker host into
a private operational engine, reachable as simple commands instead of raw
Docker/git/tailscale syntax.

This is **scripts, not software** — deliberately. No daemon, no web service,
no new attack surface. Just shell scripts an operator runs over SSH (and
later, optionally, from the phone over Tailscale).

## Scope — what this does NOT touch

- Production (`faultlinewatch.com`, Cloudflare Pages, the `-site` repo) is
  untouched. This layer only operates the private NAS deployment.
- The public and private environments remain separate. This layer does not
  merge them.
- No new public exposure. Tailscale remains the only remote access path.

## Architecture this operates on

```
GitHub (StuKeg1/faultline-observatory, private, read-only deploy key)
        |  git pull
        v
/volume1/Projects/Faultline-Observatory   (static HTML, no build step)
        |  read-only bind mount
        v
faultline-web container (nginx:alpine, port 8088)
        |
        v
tailscale container (non-ephemeral node: syn2-container-1)
        |  tailscale serve --bg --https=443
        v
https://syn2-container-1.tail14eee2.ts.net/
```

## Layout

```
/volume1/Projects/Faultline-Operator/
  bin/
    faultline            <- master dispatcher, use this one
    faultline-status      <- cockpit: repo, containers, tailscale, health, disk, backups
    faultline-doctor       <- verdict, not facts: ✓/⚠/✗ per check, overall health, exit code 0/1/2
    faultline-info         <- canonical reference: architecture, versions, network, revisions
    faultline-attention     <- runs doctor; silent/log/notify depending on result (cron target)
    faultline-notify-test    <- pings the notification subsystem only, nothing else
    faultline-update       <- fetch -> show diff -> confirm -> pull -> restart -> health check
    faultline-restart      <- restart web / tailscale / all
    faultline-logs        <- tail container logs
    faultline-backup       <- durable snapshot of repo + scripts + compose + tailscale notes
  config/
    notify.conf            <- NTFY_TOPIC for push notifications (set your own, see below)
  logs/                   <- operator action logs (one file per command, appended)
  backups/                <- backup archives (faultline-backup-<timestamp>.tar.gz), last 14 kept
  docs/
    OPERATOR_LAYER.md      <- this file
    RUNBOOK.md             <- step-by-step what to do when something is wrong
  VERSION                  <- current Operator Layer version string
```

## Installation on the NAS

```bash
ssh sjoerd@192.168.1.37 -p 28

mkdir -p /volume1/Projects/Faultline-Operator
# copy bin/, logs/, backups/, docs/ into that directory (scp, or unpack the
# provided archive there)

chmod +x /volume1/Projects/Faultline-Operator/bin/*

# Optional: put it on PATH for convenience
echo 'export PATH="/volume1/Projects/Faultline-Operator/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

After that:

```bash
faultline status
```

is the one command that should tell you whether the Observatory is healthy.

## The five questions, answered by which command

| Question | Command |
|---|---|
| Is the Observatory healthy? | `faultline status` (facts) / `faultline doctor` (verdict: ✓/⚠/✗ + GOOD/WARNING/CRITICAL) |
| What version is running privately? | `faultline status` (commit + behind-count) / `faultline info` (full reference: revision, container images, network, operator version) |
| Can I update it safely? | `faultline update` |
| Can I recover if something breaks? | `faultline backup` (+ RUNBOOK.md) |
| Can I operate it from my phone? | Push-notified if something's wrong (`faultline attention`); full operation still via SSH — see "Next steps" |

Note: `faultline health` is `doctor`'s terse sibling — binary exit code
only (0/1), no checklist output, meant for scripts that just need a
yes/no rather than a verdict to read. `attention` is what actually
bridges human operation and automation; see "The operating model" below.

## The operating model

Commands fall into four layers. This isn't a new architecture — it's how
the existing commands were already grouped; naming it just makes the
intent explicit.

```
Observation Layer      status, doctor, info
        |               (what's true right now)
        v
Attention Layer        attention, health
        |               (runs unattended; silent unless something
        |                needs a human — see below)
        v
Investigation Layer    logs
        |               (once notified, find out what/why)
        v
Action Layer           update, restart, backup
                        (change something)
```

The Attention Layer is the bridge between human operation and automation:

```
Task Scheduler (daily)
        v
faultline attention
        v
   runs faultline doctor
        v
  GOOD ──────────────► nothing happens (silence is the point)
  WARNING ───────────► recorded in logs/attention.log, no notification
  CRITICAL ──────────► recorded in logs/attention.log + push notification
                        via ntfy.sh
```

The notification itself is intentionally terse — "CRITICAL — tap for
details" — not a dump of which check failed. Notifications exist to
attract attention; diagnosis happens afterward, by running
`faultline doctor` or `faultline info` yourself. This keeps the system
from training you to ignore notifications because they're noisy, and
keeps the notification channel from becoming a second source of truth
that can drift from reality.

## Setting up notifications (ntfy.sh)

1. Generate an unguessable topic name:
   ```bash
   openssl rand -hex 16
   ```
2. Put it in `config/notify.conf`:
   ```bash
   NTFY_TOPIC="<the random string>"
   ```
3. Subscribe to that topic in the ntfy app (iOS/Android) or at
   `https://ntfy.sh/<your-topic>` in a browser.
4. Test it:
   ```bash
   curl -d "test" ntfy.sh/<your-topic>
   ```
   You should get a push within seconds.
5. Test delivery in isolation, without touching anything live:
   ```bash
   faultline notify-test
   ```
   This only pings the notification path — it does not run `doctor`, does
   not check container health, does not log anything to
   `attention.log`. It exists purely to answer "does a push actually
   arrive right now," so you can debug the notification channel itself
   without staging a fake outage.
6. Once delivery is confirmed, test the real end-to-end path:
   ```bash
   faultline attention
   ```
   If everything is healthy this will do and print nothing — that's
   correct behavior, not a bug. To verify the CRITICAL path actually
   fires, temporarily stop a container (`docker stop faultline-web`),
   run `faultline attention` again, confirm the notification arrives,
   then `docker start faultline-web` and confirm `faultline doctor` is
   GOOD again.

## Scheduling it (Synology Task Scheduler)

DSM doesn't use crontab directly — use Task Scheduler, the same
mechanism already used for the boot-time `tun` module job:

1. Control Panel → Task Scheduler → Create → Scheduled Task → User-defined script
2. User: `sjoerd`
3. Schedule: Daily, pick a time
4. Run command:
   ```bash
   /volume1/Projects/Faultline-Operator/bin/faultline-attention
   ```
5. Save, then trigger it manually once ("Run") to confirm it executes
   cleanly before trusting the schedule.



## Next steps (not built yet, deliberately)

- **Mobile operator mode**: SSH from iPhone (e.g. via Termius/Blink over
  Tailscale) already works today with zero extra setup — that's the
  honest v1 of "operate from phone." `faultline attention`'s push
  notifications now cover "tell me when something's wrong" without
  needing a dashboard; a lightweight read-only status page is still a
  reasonable next step if SSH-from-phone proves too clunky day to day.
- **MCP server / AI services / databases**: explicitly deferred until the
  command layer above is proven in daily use. Don't add capability the
  platform doesn't need yet.
- **Notification escalation / retry**: if `attention` itself fails to
  reach ntfy.sh (network blip, ntfy.sh down), it currently just logs that
  fact — no retry, no secondary channel. Worth revisiting only if it
  actually happens.
