# Runbook — Faultline Observatory (Private/NAS layer)

Use this when something's wrong, or before doing anything risky.
Always start with `faultline status`.

---

## "The site won't load (LAN or Tailscale)"

1. `faultline status` — check the "Site health" and "Containers" sections.
2. If `faultline-web` is not running:
   ```bash
   docker start faultline-web
   ```
   or rebuild from compose if `start` fails:
   ```bash
   cd /volume1/docker/faultline-web && docker compose up -d
   ```
3. If the container is running but HTTP isn't 200, check logs:
   ```bash
   faultline logs web 200
   ```
4. If LAN works but Tailscale URL doesn't, the tailnet path is the issue —
   go to the Tailscale section below.

## "Tailscale / the .ts.net URL isn't reachable"

1. `faultline status` — check the Tailscale section for node status and
   serve config.
2. Restart just the tailscale container:
   ```bash
   faultline restart tailscale
   ```
3. If it doesn't come back, the `tun` module may not have loaded (common
   after an unexpected reboot outside the Task Scheduler job):
   ```bash
   sudo modprobe tun
   ls /dev/net/tun   # should exist
   docker restart tailscale
   ```
4. Re-check serve config is still pointing at the right target:
   ```bash
   docker exec tailscale tailscale serve status
   ```
   Should show `http://192.168.1.37:8088` as the proxy target. If missing,
   re-run:
   ```bash
   docker exec tailscale tailscale serve --bg --https=443 http://192.168.1.37:8088
   ```

## "I want to publish new content"

1. Push changes to the private repo (`StuKeg1/faultline-observatory`) from
   wherever they're authored.
2. On the NAS: `faultline update`
   - Review the diff it shows you.
   - Confirm if it looks right.
   - It pulls, restarts the web container, and runs a health check.
3. Confirm: `faultline status` should show the new commit hash and HTTP 200.

If something looks wrong after an update and you need to go back:
```bash
cd /volume1/Projects/Faultline-Observatory
git log --oneline -5      # find the previous good commit
git checkout <commit-hash> -- .
docker restart faultline-web
```
This is a manual rollback — Layer 3 doesn't yet automate it. Treat any
update as reversible by hand, not by tooling, for now.

## "I think something is badly broken and I want to restore from backup"

1. Find the latest backup:
   ```bash
   ls -lt /volume1/Projects/Faultline-Operator/backups/
   ```
2. Extract it somewhere safe to inspect first — don't overwrite live data
   blindly:
   ```bash
   mkdir -p /tmp/restore-check
   tar -xzf /volume1/Projects/Faultline-Operator/backups/faultline-backup-<timestamp>.tar.gz -C /tmp/restore-check
   ```
3. The archive contains:
   - `repo/` — site content as of backup time, plus `repo-commit.txt`
   - `operator/` — the operator scripts + docs themselves
   - `compose/faultline-web/`, `compose/tailscale/` — the compose files
   - `tailscale-notes.txt` — a status snapshot (not secrets/keys)
4. Restore what's actually missing/broken — e.g. copy `repo/` content back
   into `/volume1/Projects/Faultline-Observatory` if the live repo got
   corrupted, or re-apply a compose file if it was edited incorrectly.

## "Disk space is low"

1. `faultline status` shows current usage.
2. Check backup retention — `faultline-backup` keeps the last 14 by default;
   reduce the `KEEP` variable in `bin/faultline-backup` if needed.
3. Check Docker for dangling images/volumes:
   ```bash
   docker system df
   docker system prune    # review before confirming — removes unused data
   ```

## Operating principles for any recovery action

- Read `faultline status` before and after every change.
- Prefer restart over rebuild; prefer rebuild over manual file surgery.
- Don't touch production (`faultlinewatch.com` / Cloudflare) to fix the
  private NAS layer — they are intentionally independent.
- If unsure, back up first (`faultline backup`), then act.
